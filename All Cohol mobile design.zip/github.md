repo: Efratabibi/ET
branch: main

## Last sync
date: 2026-10-03T14:19:14Z

### Updated in this project
- New mobile app design (9 screens) built on All Cohol's flows, copy and catalog data
- Bottle drawings, recipes and tab icons taken from src/app.html

## Screen map
| Screen | Repo files |
|---|---|
| Sign in | web/platform-web.js, src/i18n/en.js (gate.*) |
| Onboarding intro / spirits / result | src/app.html (.ob, .tile, .counter), src/i18n/en.js (ob.*) |
| What to make | src/app.html (#pane-mix, .drink), src/i18n/en.js (mix.*) |
| Recipe | src/app.html (DRINKS, .ings), src/i18n/en.js (drink.*) |
| My bar / Add a bottle | src/app.html (#pane-bar, bottleThumb), src/i18n/en.js (bar.*, find.*) |
| Shop | src/app.html (#pane-shop, B rows), src/i18n/en.js (shop.*) |
